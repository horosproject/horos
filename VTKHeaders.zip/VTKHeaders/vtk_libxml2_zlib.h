#ifndef vtk_libxml2_zlib_h
#define vtk_libxml2_zlib_h

#if defined(HAVE_VTK_ZLIB_H)
# include <vtk_zlib.h>
#elif defined(HAVE_ZLIB_H)
# include <zlib.h>
#endif

#endif
