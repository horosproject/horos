#!/bin/sh
echo "Do a Build Continuously"
cd /Users/antoinerosset/InsightToolkit-3.4.0
if [ -e continuous.lock ]
then exit;
else
date >continuous.lock
"/usr/bin/ctest" -D Continuous  2>&1 > "/Users/antoinerosset/InsightToolkit-3.4.0/Testing/Continuous.log"
rm continuous.lock
rm -f /Users/antoinerosset/InsightToolkit-3.4.0/Testing/Temporary/*
fi
