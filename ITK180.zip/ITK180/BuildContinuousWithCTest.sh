#!/bin/sh
echo "Do a Build Continuously"
cd /Users/rossetantoine/InsightToolkit-3.2.0
if [ -e continuous.lock ]
then exit;
else
date >continuous.lock
"/usr/bin/ctest" -D Continuous  2>&1 > "/Users/rossetantoine/InsightToolkit-3.2.0/Testing/Continuous.log"
rm continuous.lock
rm -f /Users/rossetantoine/InsightToolkit-3.2.0/Testing/Temporary/*
fi
