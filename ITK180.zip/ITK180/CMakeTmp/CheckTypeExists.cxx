/* */
#include <unistd.h>

void cmakeRequireSymbol(intptr_t dummy){(void)dummy;}
int main()
{return 0;
}
