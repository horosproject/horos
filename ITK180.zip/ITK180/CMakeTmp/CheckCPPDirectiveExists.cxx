#include <iostream>
#ifdef __BORLANDC__
 #ifndef __FUNCTION__
  #define __FUNCTION__ __FUNC__
 #endif
#endif
int main()
{
std::cout << __FUNCTION__;
  return 0;
}
