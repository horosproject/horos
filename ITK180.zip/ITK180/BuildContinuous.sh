#!/bin/sh
echo "Do a Build Continuously"
cd /Users/rossetantoine/InsightToolkit-2.8.1
if [ -e continuous.lock ]
then exit;
else
date >continuous.lock
"" "DART_ROOT-NOTFOUND/Source/Client/DashboardManager.tcl" DartConfiguration.tcl Continuous Start Update Configure Build Test Submit 2>&1 > "/Users/rossetantoine/InsightToolkit-2.8.1/Testing/Continuous.log"
rm continuous.lock
rm -f /Users/rossetantoine/InsightToolkit-2.8.1/Testing/Temporary/*
fi
