#!/bin/sh
echo "Allow Continuous to run"
cd /Users/rossetantoine/InsightToolkit-3.2.0
if [ -e continuous.lock ]
then  rm continuous.lock;
fi
