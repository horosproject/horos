#!/bin/sh
echo "Allow Continuous to run"
cd /Users/antoinerosset/InsightToolkit-3.4.0
if [ -e continuous.lock ]
then  rm continuous.lock;
fi
