#!/bin/sh
echo "Allow Continuous to run"
cd /Users/rossetantoine/InsightToolkit-2.8.1
if [ -e continuous.lock ]
then  rm continuous.lock;
fi
