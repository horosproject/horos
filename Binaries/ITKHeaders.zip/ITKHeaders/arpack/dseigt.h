extern int v3p_netlib_dseigt_(
  v3p_netlib_doublereal *rnorm,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *h__,
  v3p_netlib_integer *ldh,
  v3p_netlib_doublereal *eig,
  v3p_netlib_doublereal *bounds,
  v3p_netlib_doublereal *workl,
  v3p_netlib_integer *ierr
  );
