#ifndef vcl_generic_cfloat_h_
#define vcl_generic_cfloat_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_cfloat.hhh and run make


#endif // vcl_generic_cfloat_h_
