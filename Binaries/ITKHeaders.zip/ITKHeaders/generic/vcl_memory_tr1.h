#ifndef vcl_generic_memory_tr1_h_
#define vcl_generic_memory_tr1_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_memory_tr1.hhh and run make

// [20.6] lib.memory (additions in 0x draft: 2006-11-06)
// bad_weak_ptr
#ifndef vcl_bad_weak_ptr
#define vcl_bad_weak_ptr vcl_generic_memory_tr1_STD :: bad_weak_ptr
#endif
// shared_ptr
#ifndef vcl_shared_ptr
#define vcl_shared_ptr vcl_generic_memory_tr1_STD :: shared_ptr
#endif
// swap
#ifndef vcl_swap
#define vcl_swap vcl_generic_memory_tr1_STD :: swap
#endif
// static_pointer_cast
#ifndef vcl_static_pointer_cast
#define vcl_static_pointer_cast vcl_generic_memory_tr1_STD :: static_pointer_cast
#endif
// dynamic_pointer_cast
#ifndef vcl_dynamic_pointer_cast
#define vcl_dynamic_pointer_cast vcl_generic_memory_tr1_STD :: dynamic_pointer_cast
#endif
// const_pointer_cast
#ifndef vcl_const_pointer_cast
#define vcl_const_pointer_cast vcl_generic_memory_tr1_STD :: const_pointer_cast
#endif
// get_deleter
#ifndef vcl_get_deleter
#define vcl_get_deleter vcl_generic_memory_tr1_STD :: get_deleter
#endif
// weak_ptr
#ifndef vcl_weak_ptr
#define vcl_weak_ptr vcl_generic_memory_tr1_STD :: weak_ptr
#endif
// enable_shared_from_this
#ifndef vcl_enable_shared_from_this
#define vcl_enable_shared_from_this vcl_generic_memory_tr1_STD :: enable_shared_from_this
#endif

#endif // vcl_generic_memory_tr1_h_
