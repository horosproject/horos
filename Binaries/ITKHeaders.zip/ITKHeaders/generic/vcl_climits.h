#ifndef vcl_generic_climits_h_
#define vcl_generic_climits_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_climits.hhh and run make


#endif // vcl_generic_climits_h_
