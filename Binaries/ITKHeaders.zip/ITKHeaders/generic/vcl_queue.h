#ifndef vcl_generic_queue_h_
#define vcl_generic_queue_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_queue.hhh and run make

// queue
#ifndef vcl_queue
#define vcl_queue vcl_generic_queue_STD :: queue
#endif
// priority_queue
#ifndef vcl_priority_queue
#define vcl_priority_queue vcl_generic_queue_STD :: priority_queue
#endif

#endif // vcl_generic_queue_h_
