#ifndef vcl_generic_cstring_h_
#define vcl_generic_cstring_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_cstring.hhh and run make

// NB: size_t is declared in <cstddef>, not <cstring>
// memchr
#ifndef vcl_memchr
#define vcl_memchr vcl_generic_cstring_STD :: memchr
#endif
// memcmp
#ifndef vcl_memcmp
#define vcl_memcmp vcl_generic_cstring_STD :: memcmp
#endif
// memcpy
#ifndef vcl_memcpy
#define vcl_memcpy vcl_generic_cstring_STD :: memcpy
#endif
// memmove
#ifndef vcl_memmove
#define vcl_memmove vcl_generic_cstring_STD :: memmove
#endif
// memset
#ifndef vcl_memset
#define vcl_memset vcl_generic_cstring_STD :: memset
#endif
// strcat
#ifndef vcl_strcat
#define vcl_strcat vcl_generic_cstring_STD :: strcat
#endif
// strchr
#ifndef vcl_strchr
#define vcl_strchr vcl_generic_cstring_STD :: strchr
#endif
// strcmp
#ifndef vcl_strcmp
#define vcl_strcmp vcl_generic_cstring_STD :: strcmp
#endif
// strcoll
#ifndef vcl_strcoll
#define vcl_strcoll vcl_generic_cstring_STD :: strcoll
#endif
// strcpy
#ifndef vcl_strcpy
#define vcl_strcpy vcl_generic_cstring_STD :: strcpy
#endif
// strcspn
#ifndef vcl_strcspn
#define vcl_strcspn vcl_generic_cstring_STD :: strcspn
#endif
// strerror
#ifndef vcl_strerror
#define vcl_strerror vcl_generic_cstring_STD :: strerror
#endif
// strlen
#ifndef vcl_strlen
#define vcl_strlen vcl_generic_cstring_STD :: strlen
#endif
// strncat
#ifndef vcl_strncat
#define vcl_strncat vcl_generic_cstring_STD :: strncat
#endif
// strncmp
#ifndef vcl_strncmp
#define vcl_strncmp vcl_generic_cstring_STD :: strncmp
#endif
// strncpy
#ifndef vcl_strncpy
#define vcl_strncpy vcl_generic_cstring_STD :: strncpy
#endif
// strpbrk
#ifndef vcl_strpbrk
#define vcl_strpbrk vcl_generic_cstring_STD :: strpbrk
#endif
// strrchr
#ifndef vcl_strrchr
#define vcl_strrchr vcl_generic_cstring_STD :: strrchr
#endif
// strspn
#ifndef vcl_strspn
#define vcl_strspn vcl_generic_cstring_STD :: strspn
#endif
// strstr
#ifndef vcl_strstr
#define vcl_strstr vcl_generic_cstring_STD :: strstr
#endif
// strtok
#ifndef vcl_strtok
#define vcl_strtok vcl_generic_cstring_STD :: strtok
#endif
// strxfrm
#ifndef vcl_strxfrm
#define vcl_strxfrm vcl_generic_cstring_STD :: strxfrm
#endif

#endif // vcl_generic_cstring_h_
