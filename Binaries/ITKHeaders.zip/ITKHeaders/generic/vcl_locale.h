#ifndef vcl_generic_locale_h_
#define vcl_generic_locale_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_locale.hhh and run make

// use_facet
#ifndef vcl_use_facet
#define vcl_use_facet vcl_generic_locale_STD :: use_facet
#endif
// has_facet
#ifndef vcl_has_facet
#define vcl_has_facet vcl_generic_locale_STD :: has_facet
#endif
// isspace
#ifndef vcl_isspace
#define vcl_isspace vcl_generic_locale_STD :: isspace
#endif
// isprint
#ifndef vcl_isprint
#define vcl_isprint vcl_generic_locale_STD :: isprint
#endif
// iscntrl
#ifndef vcl_iscntrl
#define vcl_iscntrl vcl_generic_locale_STD :: iscntrl
#endif
// isupper
#ifndef vcl_isupper
#define vcl_isupper vcl_generic_locale_STD :: isupper
#endif
// islower
#ifndef vcl_islower
#define vcl_islower vcl_generic_locale_STD :: islower
#endif
// isalpha
#ifndef vcl_isalpha
#define vcl_isalpha vcl_generic_locale_STD :: isalpha
#endif
// isdigit
#ifndef vcl_isdigit
#define vcl_isdigit vcl_generic_locale_STD :: isdigit
#endif
// ispunct
#ifndef vcl_ispunct
#define vcl_ispunct vcl_generic_locale_STD :: ispunct
#endif
// isxdigit
#ifndef vcl_isxdigit
#define vcl_isxdigit vcl_generic_locale_STD :: isxdigit
#endif
// isalnum
#ifndef vcl_isalnum
#define vcl_isalnum vcl_generic_locale_STD :: isalnum
#endif
// isgraph
#ifndef vcl_isgraph
#define vcl_isgraph vcl_generic_locale_STD :: isgraph
#endif
// toupper
#ifndef vcl_toupper
#define vcl_toupper vcl_generic_locale_STD :: toupper
#endif
// tolower
#ifndef vcl_tolower
#define vcl_tolower vcl_generic_locale_STD :: tolower
#endif
// ctype
#ifndef vcl_ctype
#define vcl_ctype vcl_generic_locale_STD :: ctype
#endif
// codecvt_base
#ifndef vcl_codecvt_base
#define vcl_codecvt_base vcl_generic_locale_STD :: codecvt_base
#endif
// codecvt
#ifndef vcl_codecvt
#define vcl_codecvt vcl_generic_locale_STD :: codecvt
#endif
// codecvt_byname
#ifndef vcl_codecvt_byname
#define vcl_codecvt_byname vcl_generic_locale_STD :: codecvt_byname
#endif
// num_get
#ifndef vcl_num_get
#define vcl_num_get vcl_generic_locale_STD :: num_get
#endif
// num_put
#ifndef vcl_num_put
#define vcl_num_put vcl_generic_locale_STD :: num_put
#endif
// numpunct
#ifndef vcl_numpunct
#define vcl_numpunct vcl_generic_locale_STD :: numpunct
#endif
// numpunct_byname
#ifndef vcl_numpunct_byname
#define vcl_numpunct_byname vcl_generic_locale_STD :: numpunct_byname
#endif
// collate
#ifndef vcl_collate
#define vcl_collate vcl_generic_locale_STD :: collate
#endif
// collate_byname
#ifndef vcl_collate_byname
#define vcl_collate_byname vcl_generic_locale_STD :: collate_byname
#endif
// time_get
#ifndef vcl_time_get
#define vcl_time_get vcl_generic_locale_STD :: time_get
#endif
// time_get_byname
#ifndef vcl_time_get_byname
#define vcl_time_get_byname vcl_generic_locale_STD :: time_get_byname
#endif
// time_put
#ifndef vcl_time_put
#define vcl_time_put vcl_generic_locale_STD :: time_put
#endif
// time_put_byname
#ifndef vcl_time_put_byname
#define vcl_time_put_byname vcl_generic_locale_STD :: time_put_byname
#endif
// money_get
#ifndef vcl_money_get
#define vcl_money_get vcl_generic_locale_STD :: money_get
#endif
// money_put
#ifndef vcl_money_put
#define vcl_money_put vcl_generic_locale_STD :: money_put
#endif
// moneypunct
#ifndef vcl_moneypunct
#define vcl_moneypunct vcl_generic_locale_STD :: moneypunct
#endif
// moneypunct_byname
#ifndef vcl_moneypunct_byname
#define vcl_moneypunct_byname vcl_generic_locale_STD :: moneypunct_byname
#endif
// messages
#ifndef vcl_messages
#define vcl_messages vcl_generic_locale_STD :: messages
#endif
// messages_byname
#ifndef vcl_messages_byname
#define vcl_messages_byname vcl_generic_locale_STD :: messages_byname
#endif

#endif // vcl_generic_locale_h_
