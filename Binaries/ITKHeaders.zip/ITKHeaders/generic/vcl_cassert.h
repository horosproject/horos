#ifndef vcl_generic_cassert_h_
#define vcl_generic_cassert_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_cassert.hhh and run make


#endif // vcl_generic_cassert_h_
