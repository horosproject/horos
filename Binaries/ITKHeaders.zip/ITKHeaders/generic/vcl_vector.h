#ifndef vcl_generic_vector_h_
#define vcl_generic_vector_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_vector.hhh and run make

// vector
#ifndef vcl_vector
#define vcl_vector vcl_generic_vector_STD :: vector
#endif
// swap
#ifndef vcl_swap
#define vcl_swap vcl_generic_vector_STD :: swap
#endif

#endif // vcl_generic_vector_h_
