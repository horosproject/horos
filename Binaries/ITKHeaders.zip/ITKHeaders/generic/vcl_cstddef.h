#ifndef vcl_generic_cstddef_h_
#define vcl_generic_cstddef_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_cstddef.hhh and run make

// ptrdiff_t
#ifndef vcl_ptrdiff_t
#define vcl_ptrdiff_t vcl_generic_cstddef_STD :: ptrdiff_t
#endif
// size_t
#ifndef vcl_size_t
#define vcl_size_t vcl_generic_cstddef_STD :: size_t
#endif

#endif // vcl_generic_cstddef_h_
