#ifndef vcl_generic_limits_h_
#define vcl_generic_limits_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_limits.hhh and run make

// numeric_limits
#ifndef vcl_numeric_limits
#define vcl_numeric_limits vcl_generic_limits_STD :: numeric_limits
#endif
// float_round_style
#ifndef vcl_float_round_style
#define vcl_float_round_style vcl_generic_limits_STD :: float_round_style
#endif
// float_denorm_style
#ifndef vcl_float_denorm_style
#define vcl_float_denorm_style vcl_generic_limits_STD :: float_denorm_style
#endif
// round_toward_zero
#ifndef vcl_round_toward_zero
#define vcl_round_toward_zero vcl_generic_limits_STD :: round_toward_zero
#endif
// round_toward_neg_infinity
#ifndef vcl_round_toward_neg_infinity
#define vcl_round_toward_neg_infinity vcl_generic_limits_STD :: round_toward_neg_infinity
#endif

#endif // vcl_generic_limits_h_
