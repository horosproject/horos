#ifndef vcl_iso_queue_h_
#define vcl_iso_queue_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <queue>

#ifdef vcl_generic_queue_STD
  ** error **
#else
# define vcl_generic_queue_STD std
#endif

#include "../generic/vcl_queue.h"

#endif // vcl_iso_queue_h_
