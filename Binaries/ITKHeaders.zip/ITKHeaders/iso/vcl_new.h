#ifndef vcl_iso_new_h_
#define vcl_iso_new_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <new>

#ifdef vcl_generic_new_STD
  ** error **
#else
# define vcl_generic_new_STD std
#endif

#include "../generic/vcl_new.h"

#endif // vcl_iso_new_h_
