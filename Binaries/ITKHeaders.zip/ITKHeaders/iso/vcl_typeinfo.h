#ifndef vcl_iso_typeinfo_h_
#define vcl_iso_typeinfo_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <typeinfo>

#ifdef vcl_generic_typeinfo_STD
  ** error **
#else
# define vcl_generic_typeinfo_STD std
#endif

#include "../generic/vcl_typeinfo.h"

#endif // vcl_iso_typeinfo_h_
