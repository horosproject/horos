#ifndef vcl_iso_cctype_h_
#define vcl_iso_cctype_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <cctype>

#ifdef vcl_generic_cctype_STD
  ** error **
#else
# define vcl_generic_cctype_STD std
#endif

#include "../generic/vcl_cctype.h"

#endif // vcl_iso_cctype_h_
