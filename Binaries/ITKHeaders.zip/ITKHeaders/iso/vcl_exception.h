#ifndef vcl_iso_exception_h_
#define vcl_iso_exception_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <exception>

#ifdef vcl_generic_exception_STD
  ** error **
#else
# define vcl_generic_exception_STD std
#endif

#include "../generic/vcl_exception.h"

#endif // vcl_iso_exception_h_
