#ifndef vcl_iso_clocale_h_
#define vcl_iso_clocale_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <clocale>

#ifdef vcl_generic_clocale_STD
  ** error **
#else
# define vcl_generic_clocale_STD std
#endif

#include "../generic/vcl_clocale.h"

#endif // vcl_iso_clocale_h_
