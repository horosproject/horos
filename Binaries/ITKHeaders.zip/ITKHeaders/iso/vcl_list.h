#ifndef vcl_iso_list_h_
#define vcl_iso_list_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <list>

#ifdef vcl_generic_list_STD
  ** error **
#else
# define vcl_generic_list_STD std
#endif

#include "../generic/vcl_list.h"

#endif // vcl_iso_list_h_
