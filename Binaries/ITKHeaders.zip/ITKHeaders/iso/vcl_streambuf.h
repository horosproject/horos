#ifndef vcl_iso_streambuf_h_
#define vcl_iso_streambuf_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <streambuf>

#ifdef vcl_generic_streambuf_STD
  ** error **
#else
# define vcl_generic_streambuf_STD std
#endif

#include "../generic/vcl_streambuf.h"

#endif // vcl_iso_streambuf_h_
