#ifndef vcl_iso_cerrno_h_
#define vcl_iso_cerrno_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <cerrno>

#ifdef vcl_generic_cerrno_STD
  ** error **
#else
# define vcl_generic_cerrno_STD std
#endif

#include "../generic/vcl_cerrno.h"

#endif // vcl_iso_cerrno_h_
