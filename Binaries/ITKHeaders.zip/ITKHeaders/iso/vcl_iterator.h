#ifndef vcl_iso_iterator_h_
#define vcl_iso_iterator_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <iterator>

#ifdef vcl_generic_iterator_STD
  ** error **
#else
# define vcl_generic_iterator_STD std
#endif

#include "../generic/vcl_iterator.h"

#endif // vcl_iso_iterator_h_
