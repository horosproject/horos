#ifndef vcl_iso_cfloat_h_
#define vcl_iso_cfloat_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <cfloat>

#ifdef vcl_generic_cfloat_STD
  ** error **
#else
# define vcl_generic_cfloat_STD std
#endif

#include "../generic/vcl_cfloat.h"

#endif // vcl_iso_cfloat_h_
