#ifndef vcl_iso_utility_h_
#define vcl_iso_utility_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <utility>

#ifdef vcl_generic_utility_STD
  ** error **
#else
# define vcl_generic_utility_STD std
#endif

#include "../generic/vcl_utility.h"

#endif // vcl_iso_utility_h_
