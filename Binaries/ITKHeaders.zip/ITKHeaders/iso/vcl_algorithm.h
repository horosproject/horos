#ifndef vcl_iso_algorithm_h_
#define vcl_iso_algorithm_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <algorithm>

#ifdef vcl_generic_algorithm_STD
  ** error **
#else
# define vcl_generic_algorithm_STD std
#endif

#include "../generic/vcl_algorithm.h"

#endif // vcl_iso_algorithm_h_
