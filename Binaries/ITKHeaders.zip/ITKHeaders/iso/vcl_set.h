#ifndef vcl_iso_set_h_
#define vcl_iso_set_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <set>

#ifdef vcl_generic_set_STD
  ** error **
#else
# define vcl_generic_set_STD std
#endif

#include "../generic/vcl_set.h"

#endif // vcl_iso_set_h_
