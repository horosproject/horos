extern int v3p_netlib_dscal_(
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *da,
  v3p_netlib_doublereal *dx,
  v3p_netlib_integer *incx
  );
