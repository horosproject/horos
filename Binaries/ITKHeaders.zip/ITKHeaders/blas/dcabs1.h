extern v3p_netlib_doublereal v3p_netlib_dcabs1_(
  v3p_netlib_doublecomplex *z__
  );
