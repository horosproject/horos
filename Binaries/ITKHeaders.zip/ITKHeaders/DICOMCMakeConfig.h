
#ifndef __DICOMCMakeConfig_h_
#define __DICOMCMakeConfig_h_

/* #undef DICOM_DLL */
/* #undef DICOM_STATIC */
#define DICOM_ANSI_STDLIB
/* #undef DICOM_NO_STD_NAMESPACE */

#define DICOMPARSER_NAMESPACE itkdicomparser
#endif
