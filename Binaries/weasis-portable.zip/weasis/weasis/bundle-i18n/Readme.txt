Add language packs here.
Extract and place the content of weasis-i18n.war or weasis-i18n.zip here.