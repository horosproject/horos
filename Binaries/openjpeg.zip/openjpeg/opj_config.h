/* create opj_config.h for CMake */
/* #undef OPJ_HAVE_STDINT_H */

/*--------------------------------------------------------------------------*/
/* OpenJPEG Versioning                                                      */

/* Version number. */
#define OPJ_VERSION_MAJOR 2
#define OPJ_VERSION_MINOR 1
#define OPJ_VERSION_BUILD 0

#define OPENJPEG_PLUGIN_NAME  "openjp2_plugin" 
