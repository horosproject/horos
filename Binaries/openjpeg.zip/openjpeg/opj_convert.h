#ifndef _OPJ_CONVERT_H_
#define _OPJ_CONVERT_H_

extern void opj_convert_sycc_to_rgb(opj_image_t *img);

#endif /* _OPJ_CONVERT_H_ */
