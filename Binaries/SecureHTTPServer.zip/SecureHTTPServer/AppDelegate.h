#import <Cocoa/Cocoa.h>
@class   MyHTTPServer;

@interface AppDelegate : NSObject
{
	MyHTTPServer *httpServer;
}
@end
