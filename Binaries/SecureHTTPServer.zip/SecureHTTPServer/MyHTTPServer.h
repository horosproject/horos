#import <Cocoa/Cocoa.h>
#import "HTTPServer.h"

@interface MyHTTPServer : HTTPServer

@end

@interface MyHTTPConnection : HTTPConnection

@end