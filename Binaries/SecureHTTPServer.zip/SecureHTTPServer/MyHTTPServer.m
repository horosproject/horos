#import "MyHTTPServer.h"
#import "DDKeychain.h"

@implementation MyHTTPServer

- (id)init
{
	if(self = [super init])
	{
		[self setName:@"My HTTP Server"];
		[self setConnectionClass:[MyHTTPConnection class]];
	}
	return self;
}

@end

@implementation MyHTTPConnection

- (BOOL)isSecureServer
{
	return YES;
}

- (NSArray *)sslIdentityAndCertificates
{
	NSArray *result = [DDKeychain SSLIdentityAndCertificates];
	if([result count] == 0)
	{
		[DDKeychain createNewIdentity];
		return [DDKeychain SSLIdentityAndCertificates];
	}
	return result;
}

@end
