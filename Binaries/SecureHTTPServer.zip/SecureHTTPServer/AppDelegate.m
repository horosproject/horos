#import "AppDelegate.h"
#import "MyHTTPServer.h"


@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	// To access the server, simply type https://localhost:[port]
	// Where [port] is the port number the server is running on.
	// This will be output to the Xcode run log during execution
	
	httpServer = [[MyHTTPServer alloc] init];
//	[httpServer setType:@"_https._tcp."];
	[httpServer setDocumentRoot:[NSURL fileURLWithPath:[@"~/Sites" stringByExpandingTildeInPath]]];
	
	NSError *error;
	BOOL success = [httpServer start:&error];
	
	if(!success)
	{
		NSLog(@"Error starting HTTP Server: %@", error);
	}
	
	// From the DNS SRV Service Types List:
	//
	// NOTE: Web browsers like Safari and Internet Explorer (with the Bonjour for Windows plugin)
	// DO NOT browse for DNS-SD service type "_https._tcp" in addition to browsing for "_http._tcp".
	// This is a conscious decision to reduce proliferation of service types, to help keep
	// DNS-SD efficient on the network. Today, if a user types http://www.mybank.com/ into their
	// web browser, the web server automatically redirects the user to https://www.mybank.com/.
	// Rather than having an entirely different DNS-SD service type for https, we recommend
	// using the same redirection mechanism: advertise a plain "http" service, which consists
	// of nothing except an HTTP redirection to the desired "https" URL.
	// Work is currently being done on adding mechanisms to HTTP and TLS to allow the server
	// to tell the client that it needs to activate TLS on the current connection before
	// proceeding. If this becomes widely adopted, it further justifies the decision to
	// not create a separate DNS-SD service type "_https._tcp", because security becomes
	// just another one of the things that is negotiated on a per-connection basis (like
	// content-type negotiation today) rather than being an entirely separate thing.
}

@end
