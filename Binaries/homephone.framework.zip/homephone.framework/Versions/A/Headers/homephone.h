//
//  homephone.h
//  homephone
//
//  Created by fauze on 05/02/18.
//  Copyright © 2018 Fauze Polpeta. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for homephone.
FOUNDATION_EXPORT double homephoneVersionNumber;

//! Project version string for homephone.
FOUNDATION_EXPORT const unsigned char homephoneVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <homephone/PublicHeader.h>


