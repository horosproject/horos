//
//  HorosHomePhone.h
//  homephone
//
//  Created by fauze on 05/02/18.
//  Copyright © 2018 Fauze Polpeta. All rights reserved.
//

#import <Foundation/Foundation.h>

enum {
  
    HOME_PHONE_HOROS_STARTED      = 0x0,
    
    HOME_PHONE_2D_VIEWER_LAUNCHED = 0x100,
    
    HOME_PHONE_3DMPR_LAUNCHED     = 0x200,
    
    HOME_PHONE_3DCPR_LAUNCHED     = 0x300,
    
    HOME_PHONE_2DMPR_LAUNCHED     = 0x400,

    HOME_PHONE_3DMIP_LAUNCHED     = 0x500,
    
    HOME_PHONE_3DVOL_LAUNCHED     = 0x600,
    
    HOME_PHONE_3DSUR_LAUNCHED     = 0x700,
    
    HOME_PHONE_3DEND_LAUNCHED     = 0x800,
    
    HOME_PHONE_PLUGIN_LOADED      = 0x900, //Not used so far until implement late info collector
    
    HOME_PHONE_PLUGIN_LAUNCHED    = 0x1000,
    
};

@interface HorosHomePhone : NSObject

+ (id) sharedHomePhone;

- (void) callHomeInformingFunctionType:(NSUInteger) functionType
                                detail:(NSString*)  functionDetailString;

@end
